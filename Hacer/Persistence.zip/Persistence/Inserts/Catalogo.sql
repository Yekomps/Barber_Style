-- Inserción de datos en la tabla Catalogo
INSERT INTO Catalogo (idCatalogo, Descripcion) VALUES
(uuid_generate_v4(), 'Corte de Cabello'),
(uuid_generate_v4(), 'Afeitado'),
(uuid_generate_v4(), 'Tinte de Cabello');
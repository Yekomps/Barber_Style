-- Inserción de datos en la tabla Tipo_EstadoCivil
INSERT INTO Tipo_EstadoCivil (idTipoEstadoCivil, Descripcion) VALUES
(uuid_generate_v4(), 'Soltero'),
(uuid_generate_v4(), 'Casado'),
(uuid_generate_v4(), 'Divorciado');
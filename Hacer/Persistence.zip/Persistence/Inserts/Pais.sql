-- Inserción de datos en la tabla Pais
INSERT INTO Pais (idPais, Nombre) VALUES
(uuid_generate_v4(), 'Colombia'),
(uuid_generate_v4(), 'Argentina'),
(uuid_generate_v4(), 'México');

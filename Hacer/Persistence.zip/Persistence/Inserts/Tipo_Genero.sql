
-- Inserción de datos en la tabla Tipo_Genero
INSERT INTO Tipo_Genero (idTipoGenero, Descripcion) VALUES
(uuid_generate_v4(), 'Masculino'),
(uuid_generate_v4(), 'Femenino'),
(uuid_generate_v4(), 'No Binario');
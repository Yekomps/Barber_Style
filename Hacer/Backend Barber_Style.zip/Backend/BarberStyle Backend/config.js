import { config } from "dotenv";
config();

export const PORT  = process.env.PORT || 3000;
export const USER = process.env.USER;
export const PASSWORD = process.env.PASSWORD;
export const DBCLUSTER = process.env.DBCLUSTER;
export const COLLECTION = process.env.COLLECTION;
export const DBNAME = process.env.DBNAME;
export const IDDB = process.env.IDDB

export const MONGO_URI = `mongodb+srv://${USER}:${PASSWORD}@${DBCLUSTER}.${IDDB}.mongodb.net/`